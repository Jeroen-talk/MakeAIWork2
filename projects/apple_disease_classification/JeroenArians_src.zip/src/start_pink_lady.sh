#!/usr/bin/env bash

export LIBGL_ALLOW_SOFTWARE=1

run/main.py
