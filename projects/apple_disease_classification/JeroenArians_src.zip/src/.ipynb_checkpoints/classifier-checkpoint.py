#!/usr/bin/env python

# DEFINE IMPORTS HERE

# IMPLEMENT RUNNABLE CODE INSIDE THIS MAIN 
def main():
    pass

# DO NOT IMPLEMENT ANYTHING HERE
if __name__ == main():
    main()    